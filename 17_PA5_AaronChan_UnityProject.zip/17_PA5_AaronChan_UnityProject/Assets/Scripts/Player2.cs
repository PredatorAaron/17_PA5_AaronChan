﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class Player2 : MonoBehaviour
{
    public float MoveSpeed = 100;

    private Rigidbody thisRigibody;

    // Start is called before the first frame update
    void Start()
    {
        thisRigibody = GetComponent<Rigidbody>();
    }

    // Update is called once per frame
    void Update()
    {
        Vector3 MoveX = Input.GetAxis("Horizontal") * Vector3.right;

        Vector3 MoveZ = Input.GetAxis("Vertical") * Vector3.forward;

        Vector3 MoveDirection = MoveX + MoveZ;

        thisRigibody.AddForce(MoveDirection * MoveSpeed * Time.deltaTime);

        if (GameManager.thisManager.Coins == 4)
        {
            SceneManager.LoadScene("GameWin");
        }
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.tag == "Coin")
        {
            GameManager.thisManager.Coins += 1;
            GameManager.thisManager.Coin.text = "Coins Collected = " + GameManager.thisManager.Coins;

            Destroy(other.gameObject);
        }
    }

    private void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.tag == "Hazard")
        {
            Destroy(gameObject);
            SceneManager.LoadScene(1);
        }
    }
}